﻿using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext()
        {
        }

        public DatabaseContext(DbContextOptions<DatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Student> Student { get; set; }
        public virtual DbSet<Exam> Exam { get; set; }
        public virtual DbSet<Subject> Subject { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>(entity =>
            {
                entity.Property(e => e.Name).IsRequired();

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.Email).IsRequired();

                entity.Property(e => e.Address).IsRequired();
            });

            modelBuilder.Entity<Exam>(entity =>
            {
                entity.Property(e => e.ExamName).IsRequired();

                entity.Property(e => e.Type).IsRequired();

                entity.Property(e => e.DateTime).HasColumnType("date");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.Exams)
                    .HasForeignKey(d => d.StudentId)
                    .HasConstraintName("FK_Exams_Student");
            });

            modelBuilder.Entity<Subject>(entity =>
            {
                entity.Property(e => e.Name).IsRequired();
            });

            modelBuilder.Entity<StudentSubject>(entity =>
            {
                entity.HasKey(e => new { e.StudentId, e.SubjectId });

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.StudentSubjects)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_StudentSubjects_Student");

                entity.HasOne(d => d.Subject)
                    .WithMany(p => p.StudentSubjects)
                    .HasForeignKey(d => d.SubjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_StudentSubjects_Subject");
            });

            modelBuilder.Entity<SubjectExam>(entity =>
            {
                entity.HasKey(e => new { e.SubjectId, e.ExamId });

                entity.HasOne(d => d.Exam)
                    .WithMany(p => p.SubjectExams)
                    .HasForeignKey(d => d.ExamId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SubjectExams_Exam");

                entity.HasOne(d => d.Subject)
                    .WithMany(p => p.SubjectExams)
                    .HasForeignKey(d => d.SubjectId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SubjectExams_Subject");
            });

            modelBuilder.Entity<StudentExam>(entity =>
            {
                entity.HasKey(e => new { e.StudentId, e.ExamId });

                entity.HasOne(d => d.Exam)
                    .WithMany(p => p.StudentExams)
                    .HasForeignKey(d => d.ExamId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_StudentExams_Exam");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.StudentExams)
                    .HasForeignKey(d => d.StudentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_StudentExams_Student");
            });

            OnModelCreatingPartial(modelBuilder);

            // Seed data
            modelBuilder.Entity<Student>().HasData(
                new Student { StudentId = 1, Name = "John Doe", DateOfBirth = DateTime.Now, Email = "johndoe@example.com", Address = "123 Main Street" },
                new Student { StudentId = 2, Name = "Jane Doe", DateOfBirth = DateTime.Now, Email = "janedoe@example.com", Address = "456 Main Street" },
                new Student { StudentId = 3, Name = "John Smith", DateOfBirth = DateTime.Now, Email = "johnsmith@example.com", Address = "789 Main Street" }
            );

            modelBuilder.Entity<Subject>().HasData(
                new Subject { SubjectId = 1, Name = "Math" },
                new Subject { SubjectId = 2, Name = "English" },
                new Subject { SubjectId = 3, Name = "Science" }
            );
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
}
